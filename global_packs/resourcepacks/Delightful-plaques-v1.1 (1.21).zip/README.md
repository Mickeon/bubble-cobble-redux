# Delightful-Plaques
an **Advancement Plaques** Resource Pack that make them look more **Delightful**.
